<?php
	$con = mysqli_connect("localhost", "root", "", "ecom_store");
?>