<center><!-- center starts -->
	<h1>Pay Offline Using Method</h1>
	<p class="text-muted">
		If you have any questions, <a href="../contact.php">Contact us</a>
	</p>

</center><!-- center ends -->
<hr>

<div class="table-responsive">
	<table class="table table-bordered table-hover table-striped"><!-- table bordered starts -->
		<thead><!-- thead starts -->
			<tr>
				<th>Bank Account Details</th>
				<th>Western Union</th>
			</tr>
		</thead><!-- thead ends -->

		<tbody><!-- tbody starts -->
			<tr>
				<td>CIMB: Account No -> 123456</td>
				<td>745321</td>
			</tr>
		</tbody>	<!-- tbody ends -->
	</table><!-- table bordered ends -->
</div>