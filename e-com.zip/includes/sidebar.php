<div class="panel panel-default sidebar-menu"><!--panel panel-default sidebar-menu starts -->
	<div class="panel-heading"><!--panel heading starts -->
		<h3 class="panel-title">Products Categories</h3>
	</div><!--panel heading ends -->
		<div class="panel-body"><!--panel body starts -->
			<ul class="nav nav-pills nav-stacked category-menu">
				<?php getPCats(); ?>
			</ul>
		</div><!--panel heading ends -->
</div><!--panel panel-default sidebar-menu ends -->

<div class="panel panel-default sidebar-menu"><!--panel panel-default sidebar-menu starts -->
	<div class="panel-heading"><!--panel heading starts -->
		<h3 class="panel-title">Main Categories</h3>
	</div><!--panel heading ends -->
		<div class="panel-body"><!--panel body starts -->
			<ul class="nav nav-pills nav-stacked category-menu">
				<?php getCats(); ?>
			</ul>
		</div><!--panel heading ends -->
</div><!--panel panel-default sidebar-menu ends -->